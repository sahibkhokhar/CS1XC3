/**
 * @file student.c
 * @author Sahib Khokhar (khokhs5@mcmaster.ca)
 * @brief File which implements the student.h file.
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

void add_grade(Student* student, double grade)
{
  // increase the number of grades by 1
  student->num_grades++;

  // allocate memory for the new grade if student has no grades
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  
  // if student has grades, allocate memory for the new grade
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  
  // add grade to the student
  student->grades[student->num_grades - 1] = grade;
}

double average(Student* student)
{
  // if student has no grades, return 0
  if (student->num_grades == 0) return 0;

  double total = 0;
  // loop through all the grades in the student and add them to the total
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  // return the average of the grades
  return total / ((double) student->num_grades);
}

void print_student(Student* student)
{
  // print student details
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  
  // print all the grades in the student using a for loop
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

Student* generate_random_student(int grades)
{
  // define random set of first names to randomly use
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  // define random set of last names to randomly use
  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  // allocate memory for the new student
  Student *new_student = calloc(1, sizeof(Student));

  // randomly select a first name and a last name from the sets
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  // generate a random ID for the student storing it as a string
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  // generate grades for the student from 25 to 100 and add them to the student
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}