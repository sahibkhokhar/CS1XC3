/**
 * @file course.c
 * @author Sahib Khokhar (khokhs5@mcmaster.ca)
 * @brief File which implements the course.h file.
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>


void enroll_student(Course *course, Student *student)
{
  // increase the number of students in the course by 1
  course->total_students++;
  
  // allocate memory for the new student if course has no students in it
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  
  // if course has students in it, allocate memory for the new student
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  
  // add the student to the course
  course->students[course->total_students - 1] = *student;
}

void print_course(Course* course)
{
  // print course details
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  // print all the students in the course using a for loop
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

Student* top_student(Course* course)
{
  // if course has no students, return NULL
  if (course->total_students == 0) return NULL;
 
  // set the top student to be the first student in the course
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  // loop through all the students in the course and move pointer to the current student if the average is higher
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  // loop through all the students in the course and count the number of students who passed
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  // allocate memory for the list of students who passed
  passing = calloc(count, sizeof(Student));

  // loop through all the students in the course and add the students who had an average greater than or equal to 50 to the list of passing students
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}