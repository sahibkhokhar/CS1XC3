/**
 * @file main.c
 * @author Sahib Khokhar (khokhs5@mcmaster.ca)
 * @brief A program that demonstrates the use of the course struct.
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief The program's main function
 * 
 * @return int
 */
int main()
{
  srand((unsigned) time(NULL));

  // create a course and add its details
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  // geenerate 20 students and add them to the course with 8 random grades
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  // print the course details
  print_course(MATH101);

  // find the top student in the course and print their details
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  // create an int to store the number of passing students
  int total_passing;
  // create a list of passing students and print their details
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}