/**
 * @file student.h
 * @author Sahib Khokhar (khokhs5@mcmaster.ca)
 * @brief File which contains a class definition for a student.
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */


/**
 * @brief A struct representing a student
 * 
 */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

/**
 * @brief Function to add a grade to a student
 * 
 * @param student The student which the grade will be added to
 * @param grade The grade to be added
 */
void add_grade(Student *student, double grade);

/**
 * @brief Function to find the average of a student's grades
 * 
 * @param student The student to find the average grade of
 * @return double The average grade of the student
 */
double average(Student *student);

/**
 * @brief Function to print a student's information
 * 
 * @param student The student to print information about
 */
void print_student(Student *student);

/**
 * @brief Function to create a new student randomly
 * 
 * @param grades Number of grades to generate
 * @return Student* Pointer to the new student
 */
Student* generate_random_student(int grades); 
