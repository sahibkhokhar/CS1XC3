/**
 * @file course.h
 * @author Sahib Khokhar (khokhs5@mcmaster.ca)
 * @brief File which contains a course struct and functions to manipulate it.
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "student.h"
#include <stdbool.h>

/**
 * @brief A struct which contains a course name, a list of students, and the number of students in the course
 * 
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

/**
 * @brief Function that adds a student to the course
 * 
 * @param course The course to add the student to
 * @param student The student to add to the course
 */
void enroll_student(Course *course, Student *student);

/**
 * @brief Function to print the course name and code
 * 
 * @param course The course to be printed
 */
void print_course(Course *course);

/**
 * @brief Function that finds the top student in a course
 * 
 * @param course The course to find the top student in
 * @return Student* Pointer to the top student in the course
 */
Student *top_student(Course* course);

/**
 * @brief Function that creates a list of passing students in a course
 * 
 * @param course The course to find the passing students in
 * @param total_passing Pointer to an int which will contain the number of passing students
 * @return Student* Pointer to the list of passing students
 */
Student *passing(Course* course, int *total_passing);


